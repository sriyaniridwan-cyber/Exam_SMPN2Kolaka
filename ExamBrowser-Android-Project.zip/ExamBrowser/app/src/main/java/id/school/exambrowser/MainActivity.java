package id.school.exambrowser;

import android.Manifest;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class MainActivity extends AppCompatActivity {
    private static final int GREEN = Color.rgb(23, 107, 69);
    private static final int DARK = Color.rgb(13, 74, 46);
    private SharedPreferences prefs;
    private WebView webView;
    private LinearLayout root;
    private String examUrl = "https://";
    private boolean examActive = false;
    private final ActivityResultLauncher<String> cameraPermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) startScanner(); else toast("Izin kamera diperlukan untuk memindai QR.");
            });
    private final ActivityResultLauncher<ScanOptions> scanLauncher = registerForActivityResult(
            new ScanContract(), result -> {
                if (result.getContents() != null) {
                    String value = result.getContents().trim();
                    if (isSafeWebUrl(value)) { examUrl = value; openExam(); }
                    else toast("QR tidak berisi alamat web HTTP/HTTPS yang valid.");
                }
            });

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        prefs = getSharedPreferences("exam_browser", MODE_PRIVATE);
        examUrl = prefs.getString("exam_url", "https://");
        showHome();
    }

    private void showHome() {
        examActive = false;
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(20)); root.setBackgroundColor(Color.rgb(241,248,244));
        TextView title = text("EXAM BROWSER", 26, Color.WHITE, true); title.setGravity(Gravity.CENTER);
        TextView subtitle = text("SECURE EXAMINATION SYSTEM", 12, Color.WHITE, false); subtitle.setGravity(Gravity.CENTER);
        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setGravity(Gravity.CENTER);
        header.setPadding(dp(12),dp(24),dp(12),dp(24)); header.setBackground(bg(GREEN,18)); header.addView(title); header.addView(subtitle);
        root.addView(header, matchWrap());
        TextView note = text("Selamat datang. Pindai QR ujian atau masukkan alamat ujian dari sekolah.", 14, DARK, false);
        note.setPadding(0,dp(22),0,dp(14)); root.addView(note);
        addButton("PINDAI QR UJIAN", this::requestScan);
        addButton("BUAT QR CODE", this::showQrGenerator);
        addButton("BUKA HALAMAN UJIAN", this::askExamUrl);
        addButton("PENGATURAN ADMIN", this::adminLogin);
        TextView disclaimer = text("Catatan: pada HP pribadi, Android tidak mengizinkan aplikasi biasa menjamin penguncian total. Aplikasi memakai layar aman, fullscreen, dan deteksi perpindahan aplikasi; pembatasan sistem tertentu bergantung pada perangkat.", 12, Color.DKGRAY, false);
        disclaimer.setPadding(0,dp(18),0,0); root.addView(disclaimer);
        setContentView(root);
    }

    private void addButton(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTextSize(15);
        b.setBackground(bg(GREEN,12)); LinearLayout.LayoutParams lp = matchWrap(); lp.topMargin = dp(10); root.addView(b,lp); b.setOnClickListener(v -> action.run());
    }

    private void askExamUrl() {
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint("https://alamat-ujian-sekolah.id"); input.setText(examUrl.equals("https://") ? "" : examUrl);
        new AlertDialog.Builder(this).setTitle("Alamat ujian").setView(input)
            .setNegativeButton("Batal",null).setPositiveButton("Lanjut",(d,w)->{
                String value=input.getText().toString().trim();
                if (!isSafeWebUrl(value)) { toast("Gunakan alamat HTTPS yang valid."); return; }
                examUrl=value; prefs.edit().putString("exam_url",examUrl).apply(); openExam();
            }).show();
    }

    private void openExam() {
        if (!isSafeWebUrl(examUrl)) { askExamUrl(); return; }
        examActive=true;
        webView = new WebView(this); webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                return !"https".equalsIgnoreCase(uri.getScheme()) && !"http".equalsIgnoreCase(uri.getScheme());
            }
        });
        setContentView(webView); webView.loadUrl(examUrl); enterImmersive();
    }

    private void enterImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && examActive) enterImmersive();
        if (!hasFocus && examActive) toast("Perhatian: perpindahan dari layar ujian terdeteksi.");
    }

    @Override public void onBackPressed() {
        if (examActive) {
            new AlertDialog.Builder(this).setTitle("Keluar dari ujian?")
                .setMessage("Percobaan keluar dapat dicatat oleh sistem ujian. Lanjutkan hanya jika diizinkan pengawas.")
                .setNegativeButton("Kembali ke ujian",(d,w)->enterImmersive())
                .setPositiveButton("Keluar",(d,w)->showHome()).show();
        } else super.onBackPressed();
    }

    private void showQrGenerator() {
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint("Masukkan URL ujian atau kode sesi");
        new AlertDialog.Builder(this).setTitle("Buat QR Code").setView(input).setNegativeButton("Batal",null)
            .setPositiveButton("Buat",(d,w)->{
                String value=input.getText().toString().trim(); if(value.isEmpty()){toast("Isi data QR terlebih dahulu.");return;}
                try {
                    BitMatrix matrix=new MultiFormatWriter().encode(value, BarcodeFormat.QR_CODE, 720,720);
                    Bitmap bitmap=Bitmap.createBitmap(720,720,Bitmap.Config.RGB_565);
                    for(int x=0;x<720;x++) for(int y=0;y<720;y++) bitmap.setPixel(x,y,matrix.get(x,y)?Color.BLACK:Color.WHITE);
                    ImageView image=new ImageView(this); image.setImageBitmap(bitmap); image.setAdjustViewBounds(true); image.setPadding(dp(12),dp(12),dp(12),dp(12));
                    new AlertDialog.Builder(this).setTitle("QR Code ujian").setView(image).setPositiveButton("Tutup",null).show();
                } catch(WriterException e){toast("QR Code gagal dibuat.");}
            }).show();
    }

    private void requestScan() {
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) startScanner();
        else cameraPermission.launch(Manifest.permission.CAMERA);
    }
    private void startScanner() {
        ScanOptions options=new ScanOptions(); options.setPrompt("Arahkan kamera ke QR Code ujian"); options.setBeepEnabled(false); options.setOrientationLocked(false); options.setDesiredBarcodeFormats(ScanOptions.QR_CODE);
        scanLauncher.launch(options);
    }

    private void adminLogin() {
        EditText pin=new EditText(this); pin.setInputType(2); pin.setHint("PIN admin");
        new AlertDialog.Builder(this).setTitle("Login admin").setMessage("PIN awal: 123456 (segera ubah setelah instalasi)").setView(pin)
            .setNegativeButton("Batal",null).setPositiveButton("Masuk",(d,w)->{
                String saved=prefs.getString("admin_pin","123456");
                if(pin.getText().toString().equals(saved)) adminSettings(); else toast("PIN admin salah.");
            }).show();
    }
    private void adminSettings() {
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(16),dp(8),dp(16),0); box.setOrientation(LinearLayout.VERTICAL);
        EditText url=new EditText(this); url.setHint("URL ujian HTTPS"); url.setText(examUrl); box.addView(url);
        EditText newPin=new EditText(this); newPin.setHint("PIN admin baru (kosongkan jika tidak diubah)"); newPin.setInputType(2); box.addView(newPin);
        new AlertDialog.Builder(this).setTitle("Pengaturan admin").setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
            String u=url.getText().toString().trim();
            if(!isSafeWebUrl(u)){toast("URL harus menggunakan HTTPS yang valid.");return;}
            examUrl=u; SharedPreferences.Editor edit=prefs.edit().putString("exam_url",u);
            String p=newPin.getText().toString().trim(); if(!p.isEmpty()){if(p.length()<6){toast("PIN minimal 6 angka.");return;} edit.putString("admin_pin",p);}
            edit.apply(); toast("Pengaturan disimpan.");
        }).show();
    }

    private boolean isSafeWebUrl(String value) {
        try { Uri u=Uri.parse(value); return ("https".equalsIgnoreCase(u.getScheme()) || "http".equalsIgnoreCase(u.getScheme())) && u.getHost()!=null && !u.getHost().isEmpty(); }
        catch(Exception e){return false;}
    }
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private LinearLayout.LayoutParams matchWrap(){return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
