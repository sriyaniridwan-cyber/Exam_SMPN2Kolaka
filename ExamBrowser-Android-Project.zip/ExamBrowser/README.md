# Exam Browser (Android)

Starter project Android Studio untuk aplikasi Exam Browser bertema hijau.

## Konfigurasi
- Minimum Android: 8.0 (API 26)
- Bahasa: Java
- UI: Android native
- Fitur awal: WebView HTTPS, QR generator, QR scanner, PIN admin lokal, fullscreen immersive, FLAG_SECURE, deteksi kehilangan fokus, dan dialog konfirmasi keluar.

## Membuka dan membangun
1. Instal Android Studio versi stabil.
2. Buka folder `ExamBrowser` sebagai project.
3. Gunakan JDK 17 dan izinkan Gradle mengunduh dependensi.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Penting tentang keamanan pada HP pribadi
Android tidak memberikan hak kepada aplikasi biasa untuk mengunci seluruh perangkat secara mutlak. `FLAG_SECURE` membantu mencegah screenshot/rekaman layar pada banyak perangkat; immersive fullscreen menyembunyikan navigasi; aplikasi memberi peringatan ketika kehilangan fokus. Ini bukan jaminan anti-keluar atau anti-split-screen pada semua merek Android. Penguncian Lock Task Mode yang kuat memerlukan perangkat terkelola/Device Owner dan kebijakan administrator.

## Sebelum dipakai ujian sungguhan
- Ubah PIN admin awal `123456` dari menu Pengaturan Admin.
- Gunakan situs ujian HTTPS yang tepercaya.
- Uji di berbagai merek dan versi Android.
- Tambahkan pencatatan pelanggaran dan validasi token di server ujian bila diperlukan.
- Jangan menganggap peringatan kehilangan fokus sebagai bukti kecurangan; perpindahan fokus dapat terjadi karena panggilan, notifikasi, atau gangguan sistem.

## Catatan rilis
Ini adalah proyek sumber awal, bukan APK yang sudah dikompilasi atau diuji di perangkat. Kompilasi memerlukan Android Studio/Android SDK dan pengunduhan dependensi Gradle.
